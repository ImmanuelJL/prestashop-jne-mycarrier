<?php
/*                  NOTE                  *
*******************************************/
/* Cek http://immanueljl.blogspot.co.id untuk informasi lebih lanjut.
* Dukung dengan like dan share :)
* ****************************************************
* @author  Immanuel Julianto Lasmana <immanueljl44@gmail.com>
* @site    http://immanueljl.blogspot.co.id
* @copyright  Copyright (c)2017 
* @license    FREE LICENSE SOFTWARE (BOLEH DIPAKAI UNTUK KEPERLUAN APAPUN TANPA MERUBAH COPYRIGHT NOTICE)
*/
if (!defined('_PS_VERSION_')) {
    exit;
}

class mycarrier extends CarrierModule
{
    const PREFIX = 'mycarrier_mcj_';

    public $id_carrier;

    protected $_hooks = array(        
        'actionCarrierUpdate',
    );

    protected $_carriers = array(
        'OKE (Ongkos Kirim Ekonomis)' => 'mcj',//PUT CARRIER NAME
        'REG (Reguler)' => 'mcj2',//PUT CARRIER NAME
        'YES (Yakin Esok Sampai)' => 'mcj3',//PUT CARRIER NAME
    );

    public function __construct()
    {
        $this->name = 'mycarrier';//MOLDULE NAME
        $this->tab = 'shipping_logistics';//TAB MODULE
        $this->version = '1.0';//MODULE VERSION
        $this->author = 'Immanuel Julianto Lasmana';//CREATOR
        $this->bootstrap = TRUE;
        $this->module_key = '';

        parent::__construct();

        $this->displayName = $this->l('My Carrier');
        $this->description = $this->l('My carrier, hitung ongkir jasa pengiriman barang atau ekspedisi via Jalur Nugraha Ekakurir (JNE). Menggunakan API dari http://ongkir.info. Module untuk prestashop GRATIS buatan Immanuel Julianto Lasmana, untuk dokumentasi cek http://immanueljl.blogspot.co.id');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
 
        if (!Configuration::get('myc_api'))      
          $this->warning = $this->l('No API Provided');

        if (!Configuration::get('myc_city'))      
          $this->warning = $this->l('No City From Provided');
    }

    public function install()
    {
        if (parent::install()) {//INSTALL HOOK
            foreach ($this->_hooks as $hook) {
                if (!$this->registerHook($hook)) {
                    return FALSE;
                }
            }

            if (!$this->installDB()) {//INSTALL DATABASE
                return FALSE;
            }

            if (!$this->createCarriers()) {//INSTAL CARRIER
                return FALSE;
            }

            return TRUE;
        }

        return FALSE;
    }

    protected function uninstallDB()
    {
        $sql = array();

        $sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'mycarrier_jne_ijl`';

        foreach ($sql as $_sql) {
            if (!Db::getInstance()->Execute($_sql)) {
                return FALSE;
            }
        }

        return TRUE;
    }

    protected function installDB()
    {
        $sql = array();

        $sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'mycarrier_jne_ijl` (
            `id_mycarrier_jne_ijl` INT( 11 ) UNSIGNED NOT NULL AUTO_INCREMENT,
            `api_key` TEXT,
            `from_city` TEXT,
            `date_upd` DATETIME NULL,
            PRIMARY KEY (`id_mycarrier_jne_ijl`)
        ) ENGINE = ' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8';

        foreach ($sql as $_sql) {
            if (!Db::getInstance()->Execute($_sql)) {
                return FALSE;
            }
        }        

        return TRUE;
    }

    protected function createCarriers()
    {
        //INSERT DATABASE 
        Db::getInstance()->autoExecute(_DB_PREFIX_ . 'mycarrier_jne_ijl', array(
            'api_key' => pSQL('xxxxxxxxxxxxxxxxxxxx'),
            'from_city' => pSQL('Jakarta'),
        ), 'INSERT');
        
            foreach ($this->_carriers as $key => $value) {
                //Create own carrier
                $carrier = new Carrier();
                $carrier->name = $key;
                $carrier->active = TRUE;
                $carrier->deleted = 0;
                $carrier->shipping_handling = FALSE;
                $carrier->range_behavior = 0;
                $carrier->delay[Configuration::get('PS_LANG_DEFAULT')] = 'JNE (Jalur Nugraha Ekakurir)';
                $carrier->shipping_external = TRUE;
                $carrier->is_module = TRUE;
                $carrier->external_module_name = $this->name;
                $carrier->need_range = TRUE;

                if ($carrier->add()) {
                    $groups = Group::getGroups(true);
                    foreach ($groups as $group) {
                        Db::getInstance()->autoExecute(_DB_PREFIX_ . 'carrier_group', array(
                            'id_carrier' => (int) $carrier->id,
                            'id_group' => (int) $group['id_group']
                        ), 'INSERT');
                    }

                    $rangePrice = new RangePrice();
                    $rangePrice->id_carrier = $carrier->id;
                    $rangePrice->delimiter1 = '0';
                    $rangePrice->delimiter2 = '1000000';
                    $rangePrice->add();

                    $rangeWeight = new RangeWeight();
                    $rangeWeight->id_carrier = $carrier->id;
                    $rangeWeight->delimiter1 = '0';
                    $rangeWeight->delimiter2 = '1000000';
                    $rangeWeight->add();

                    $zones = Zone::getZones(true);
                    foreach ($zones as $z) {
                        Db::getInstance()->autoExecute(_DB_PREFIX_ . 'carrier_zone',
                            array('id_carrier' => (int) $carrier->id, 'id_zone' => (int) $z['id_zone']), 'INSERT');
                        Db::getInstance()->autoExecuteWithNullValues(_DB_PREFIX_ . 'delivery',
                            array('id_carrier' => $carrier->id, 'id_range_price' => (int) $rangePrice->id, 'id_range_weight' => NULL, 'id_zone' => (int) $z['id_zone'], 'price' => '25'), 'INSERT');
                        Db::getInstance()->autoExecuteWithNullValues(_DB_PREFIX_ . 'delivery',
                            array('id_carrier' => $carrier->id, 'id_range_price' => NULL, 'id_range_weight' => (int) $rangeWeight->id, 'id_zone' => (int) $z['id_zone'], 'price' => '25'), 'INSERT');
                    }

                    copy(dirname(__FILE__) . '/views/img/carrier.jpg', _PS_SHIP_IMG_DIR_ . '/' . (int) $carrier->id . '.jpg');

                    Configuration::updateValue(self::PREFIX . $value, $carrier->id);
                    Configuration::updateValue(self::PREFIX . $value . '_reference', $carrier->id);
                }
            }//end of foreach ($this->_carriers as $key => $value) {
                        
        return TRUE;
    }

    protected function deleteCarriers()
    {
        foreach ($this->_carriers as $value) {
            $tmp_carrier_id = Configuration::get(self::PREFIX . $value);
            $carrier = new Carrier($tmp_carrier_id);
            $carrier->delete();
        }

        return TRUE;
    }

    public function uninstall()
    {
        if (parent::uninstall()) {
            foreach ($this->_hooks as $hook) {
                if (!$this->unregisterHook($hook)) {
                    return FALSE;
                }
            }

            if (!$this->uninstallDB()) {
                return FALSE;
            }

            if (!$this->deleteCarriers()) {
                return FALSE;
            }

            return TRUE;
        }

        return FALSE;
    }

    public function getContent()
    {
        $output = null;
     
        if (Tools::isSubmit('submit'.$this->name))
        {
            $my_carrier_api = strval(Tools::getValue('myc_api'));
            $my_carrier_city = strval(Tools::getValue('myc_city'));
            if (!$my_carrier_api
              || empty($my_carrier_api)
              || !Validate::isGenericName($my_carrier_api)
              || !$my_carrier_city
              || empty($my_carrier_city)
              || !Validate::isGenericName($my_carrier_city))
                $output .= $this->displayError($this->l('Invalid Configuration Value'));
            else
            {
                Configuration::updateValue('myc_api', $my_carrier_api);
                Configuration::updateValue('myc_city', $my_carrier_city);
                //UPDATE DATABASE
                Db::getInstance()->autoExecute(_DB_PREFIX_ . 'mycarrier_jne_ijl', array(
                    'api_key' => pSQL($my_carrier_api),
                    'from_city'      => pSQL($my_carrier_city),
                ), 'UPDATE' ,'id_mycarrier_jne_ijl = 1');
                $output .= $this->displayConfirmation($this->l('Settings updated'));

            }
        }
        return $output.$this->displayForm();
    }

    public function displayForm()
        {

        // Get default language
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
         
        // Init Fields form array
        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('My Carrier Setting'),
            ),
            'input' => array(
                array(
                    'type' => 'text',
                    'label' => $this->l('API Key'),
                    'name' => 'myc_api',
                    'size' => 50,
                    'required' => true
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('City From'),
                    'name' => 'myc_city',
                    'size' => 50,
                    'required' => true
                )
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            )
        );
         
        $helper = new HelperForm();
         
        // Module, token and currentIndex
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
         
        // Language
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;
         
        // Title and toolbar
        $helper->title = $this->displayName;
        $helper->show_toolbar = true;        // false -> remove toolbar
        $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
        $helper->submit_action = 'submit'.$this->name;
        $helper->toolbar_btn = array(
            'save' =>
            array(
                'desc' => $this->l('Save'),
                'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
                '&token='.Tools::getAdminTokenLite('AdminModules'),
            ),
            'back' => array(
                'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Back to list')
            )
        );
         
        // Load current value
        $helper->fields_value['myc_api'] = Configuration::get('myc_api');
        $helper->fields_value['myc_city'] = Configuration::get('myc_city');
         
        return $helper->generateForm($fields_form);
    }

    public function getOrderShippingCost($params, $shipping_cost)//CALCULATE SHIPPING COST HERE
    {

      //GET API KEY & CITY FROM DATABASE
      $sqlMyCarrier = 'SELECT * FROM '._DB_PREFIX_.'mycarrier_jne_ijl WHERE id_mycarrier_jne_ijl = 1';
      if ($rowMyCarrier = Db::getInstance()->getRow($sqlMyCarrier))        
     
      $address = new Address($this->context->cart->id_address_delivery);//GET CURRENT CUSTOMER ADDRESS DELIVERY

      $from = $rowMyCarrier['from_city'];
      $to = $address->city;
      $weight = $this->context->cart->getTotalWeight();//GET TOTAL WEIGHT PN CART
      if($weight<1){//SET THE DEFFAULT IF WEIGHT IF BELOW 1 KG
        $weight=1;
      }

      require_once 'controllers/front/REST_Ongkir.php';

      $rest = new REST_Ongkir(array(
          'server' => 'http://api.ongkir.info/'
      ));
      
      $result = $rest->post('cost/find', array(
          'from' => $from,
          'to' => $to,
          'weight' => $weight.'000',
          'courier' => 'jne',
          'API-Key' =>$rowMyCarrier['api_key']
      ));

      $prices = $result['price'];

        $ongkirOke=$prices->item[0]->value;//PREPARE ONGKIR VALUE
        if(!$prices->item[0]->value){
            $ongkirOke=false;
        }
        $ongkirReg=$prices->item[1]->value;//PREPARE ONGKIR VALUE
        if(!$prices->item[1]->value){
            $ongkirReg=false;
        }
        $ongkirYes=$prices->item[2]->value;//PREPARE ONGKIR VALUE
        if(!$prices->item[2]->value){
            $ongkirYes=false;
        }

        if ($this->id_carrier == (int)(Configuration::get(self::PREFIX.'mcj_reference')))
            return $ongkirOke;//ONGKIR KATEGORI OKE
        if ($this->id_carrier == (int)(Configuration::get(self::PREFIX.'mcj2_reference')))
            return $ongkirReg;//ONGKIR KATEGORI REG
        if ($this->id_carrier == (int)(Configuration::get(self::PREFIX.'mcj3_reference')))
            return $ongkirYes;//ONGKIR KATEGORI YES
        return false;//HILANGKAN CARRIER BILA ONGKIR TIDAK TERSEDIA
    }

    public function getOrderShippingCostExternal($params)//USE THIS IF CARRIER NEED RANGE = 0
    {
        return $this->getOrderShippingCost($params, 0);
    }

    public function hookActionCarrierUpdate($params)//This hook is required to ensure that the module will not lose connection with the carrier, created by the module
    {
        if ($params['carrier']->id_reference == Configuration::get(self::PREFIX . 'mcj_reference')) {
            Configuration::updateValue(self::PREFIX . 'mcj', $params['carrier']->id);
        }
        if ($params['carrier']->id_reference == Configuration::get(self::PREFIX . 'mcj2_reference')) {
            Configuration::updateValue(self::PREFIX . 'mcj2', $params['carrier']->id);
        }
        if ($params['carrier']->id_reference == Configuration::get(self::PREFIX . 'mcj3_reference')) {
            Configuration::updateValue(self::PREFIX . 'mcj3', $params['carrier']->id);
        }
    }

}